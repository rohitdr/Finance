<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
 
  <style>
    #footer {
    bottom: 0;
    color: #707070;
    height: 2em;
    left: 0;
    position: relative; //changed to relative from fixed also works if position is not there
    font-size: small;
    width:100%;
}
  </style>


</head>
  <body>
    
 

  <nav class="navbar navbar-expand-lg bg-light navbar-dark bg-dark">
        <!-- <a class="navbar-brand" href="#" style="margin-right:5px">
          <img src="F.jpg" alt="ANIL" width="30" height="30">
        </a> -->
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <a class="navbar-brand" href="financial_advisor.html">ANIL MAURYA</a>
          <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="financial_advisor.html">HOME</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="services.html">SERVICES</a>
              </li>
              
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  PRODUCTS
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="first.html">action</a></li>
                  <li><a class="dropdown-item" href="second.html">Another action</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item" href="third.html">Something else here</a></li>
                </ul>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="#">CONTACT US</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="friend.html">BOBBSEY TWIN</a>
              </li>
             </ul>
            <form class="d-flex" role="search">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
          </div>
        </div>
      </nav>


     





    









<div >

<div style="background-color: lightgrey; width:50%; height: 700px; float:left;">

 
<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
    
   $name = $_POST['nameing'];
   $email = $_POST['email'];
   $number = $_POST['number'];
   $reaso = $_POST['reason'];
$servername = "sql101.epizy.com";
$username = "epiz_32952641";
$password = "musREr6Jaj2d1eH";
$database = "epiz_32952641_mohit";
$conn = mysqli_connect($servername, $username, $password, $database);
if (!$conn){
   die("Sorry we failed to connect: ". mysqli_connect_error());
}

else{
$sql = "insert into reason (name, email, number, reason) VALUES ('$name', '$email', '$number' , '$reaso')";

$result= mysqli_query($conn, $sql);
if($result){
   echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
   <strong>Success!</strong> Your entry has been submitted successfully!
   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
     <span aria-hidden="true">×</span>
   </button>
 </div>';
 }
 else{
     // echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
     echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
   <strong>Error!</strong> We are facing some technical issue and your entry ws not submitted successfully! We regret the inconvinience caused!
   <button type="button" class="close" data-dismiss="alert" aria-label="Close">
     <span aria-hidden="true">×</span>
   </button>
 </div>';
 }





}


}













?> 
    <div class="container mt-3">
        <h1 >Please enter your deails for me to contact your</h1>
            <form action="contactus.php" method="post">
            <div class="form-group">
                <label for="nameing">NAME</label>
                <input type = "text" class="form-control" id= "nameing" name="nameing">
            </div>
            <div class="form-group">
                <label for="email">Email address</label>
                <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp">
                <small id="emailHelp" class="form-text text-muted">We will never share your email with anyone else.</small>
            </div>
            <div class="form-group">
                <label for="number">Phone Number</label>
                <input type="number" class="form-control" id="number" name="number">
            </div>
            <div class="form-group">
                <label for="reason">Full Biodata</label>
                <textarea class="form-control" id="reason" name="reason" rows = 5 cols = 5></textarea>
            </div>
            <div class="form-group mt-2">
              <div>
            <label for="avatar">UPLOAD YOUR ID CARD:</label>
            </div><div>
      <input type="file"
       id="avatar" name="avatar"
       accept="image/png, image/jpeg">
       </div>
       <div>
            <label for="avatar">UPLOAD YOUR SIGNATURE:</label>
            </div><div>
      <input type="file"
       id="avatar" name="avatar"
       accept="image/png, image/jpeg">
       </div>
  </div>
  

            <div>
              <div style = " float:left;"><button type="submit" class="btn btn-primary mt-4 float:right"  >Submit</button>
            </div><div  style = " float:right;">
              <img src="download.png" alt=""height = 50px class = "mt-4">
            </div>
            </div>
            
            </form>
            </div>
            
</div>
        </div>
        <div style=" width: 100% height:100% margin: auto
        display: block">

<div style=" width: 50%; height: 600px; float:left;">
<img src="give-money-vector-outline-icon-260nw-1520378267.webp" alt="" height= 600px width = 100%>
</div>

        </div>




        <div class="container bg-dark text-white rounded-4  width = 100%" >
        <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
          <p class="col-md-4 mb-0 text-muted">© 2022 Company, Inc</p>
      
          <a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
            <svg class="bi me-2" width="30" height="32"><use xlink:href="#bootstrap"></use></svg>
          </a>
      
          <ul class="nav col-md-4 justify-content-end">
            <li class="nav-item active"><a href="financial_advisor.html" class="nav-link px-2 text-muted">ANIL KUMAR</a></li>
            <li class="nav-item active"><a href="financial_advisor.html" class="nav-link px-2 text-muted">Home</a></li>
            <li class="nav-item"><a href="services.html" class="nav-link px-2 text-muted">Services</a></li>
            <li class="nav-item"><a href="contactus.php" class="nav-link px-2 text-muted">Contact Me</a></li>
            
          </ul>
        </footer>
      </div>
 




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html>